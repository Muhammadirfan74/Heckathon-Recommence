import Image from "next/image";
// import Pagetwo from "./components/Pagetwo";
// import Header from "./components/Header";

export default function Home() {
  return ( <div>   


   </div>
  );
}
